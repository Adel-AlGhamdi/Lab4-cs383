<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Models\Plan; // لا تنسَ إضافة هذا السطر في أعلى الملف
use App\Models\GymSession; // أضفه في أعلى الملف
use App\Models\User;
use App\Http\Controllers\PlanController;
use App\Http\Controllers\TrainerController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';





// مسارات محمية (يجب تسجيل الدخول للوصول إليها)
Route::middleware(['auth'])->group(function () {
    
        // حماية رابط الأدمن
            Route::get('/admin/dashboard', function () {
        $plans = Plan::withTrashed()->get();
    $stats = [
        'total_plans' => Plan::count(),
        'total_trainers' => User::where('role', 'trainer')->count(),
        'total_revenue' => Plan::sum('price'),
    ];
    return view('admin-dashboard', compact('plans', 'stats'));
})->middleware(['auth', 'role:admin'])->name('admin.dashboard');

        // حماية رابط المدرب
            Route::get('/trainer/dashboard', function () {
        $sessions = GymSession::all(); // جلب جميع الحصص
        return view('trainer-dashboard', compact('sessions'));
        })->middleware(['auth', 'role:trainer'])->name('trainer.dashboard');
});

Route::get('lang/{locale}', function ($locale) {
    if (in_array($locale, ['en', 'ar'])) {
        session(['locale' => $locale]);
    }
    return redirect()->back();
})->name('lang.switch');



Route::delete('/plans/{id}', [PlanController::class, 'destroy'])->name('plans.destroy')->middleware(['auth', 'role:admin']);
Route::post('/plans/{id}/restore', [App\Http\Controllers\PlanController::class, 'restore'])->name('plans.restore');

// مسار عرض صفحة إضافة خطة جديدة
Route::get('/admin/plans/create', [PlanController::class, 'create'])->name('plans.create')->middleware(['auth', 'role:admin']);

// مسار حفظ الخطة الجديدة في قاعدة البيانات
Route::post('/admin/plans', [PlanController::class, 'store'])->name('plans.store')->middleware(['auth', 'role:admin']);

// مسار الاسترجاع (تأكد من وجوده أيضاً)
Route::post('/admin/plans/{id}/restore', [PlanController::class, 'restore'])->name('plans.restore')->middleware(['auth', 'role:admin']);

Route::get('/admin/plans/{id}/edit', [PlanController::class, 'edit'])->name('plans.edit');
Route::put('/admin/plans/{id}', [PlanController::class, 'update'])->name('plans.update');

Route::patch('/trainer/session/{id}/status', [TrainerController::class, 'updateStatus'])->name('trainer.updateStatus');