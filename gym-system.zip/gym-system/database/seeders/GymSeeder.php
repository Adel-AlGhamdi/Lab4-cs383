<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Plan;
use App\Models\GymSession;
use Illuminate\Support\Facades\Hash;

class GymSeeder extends Seeder
{
    public function run(): void
    {
        // 1. Create Demo Users
        User::create([
            'name' => 'Admin User',
            'email' => 'admin@test.com',
            'password' => Hash::make('password'),
            'role' => 'admin',
        ]);

        User::create([
            'name' => 'Trainer User',
            'email' => 'trainer@test.com',
            'password' => Hash::make('password'),
            'role' => 'trainer',
        ]);

        // 2. Create 15 Plans
        for ($i = 1; $i <= 15; $i++) {
            Plan::create([
                'name' => "Premium Plan $i",
                'price' => rand(100, 500),
                'duration_days' => rand(30, 365),
            ]);
        }

        // 3. Create 15 Gym Sessions
        for ($i = 1; $i <= 15; $i++) {
            GymSession::create([
                'title' => "Workout Session $i",
                'description' => "Professional training description for session $i",
                'start_time' => now()->addDays(rand(1, 10)),
                'capacity' => rand(10, 30),
            ]);
        }
    }
}