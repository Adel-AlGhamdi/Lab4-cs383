<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('gym_sessions', function (Blueprint $table) {
        $table->id();
        $table->string('title');         // عنوان الحصة (مثلاً: كاريو، كمال أجسام)
        $table->text('description');     // وصف الحصة
        $table->dateTime('start_time');  // وقت البدء
        $table->integer('capacity');     // السعة القصوى للمتدربين
        $table->softDeletes();           // مطلوب لدعم الحذف الناعم
        $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('gym_sessions');
    }
};
