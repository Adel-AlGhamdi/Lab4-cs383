<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('plans', function (Blueprint $table) {
            $table->id();
            $table->string('name');          // اسم الخطة 
            $table->decimal('price', 8, 2);  // السعر 
            $table->integer('duration_days');// مدة الخطة 
            $table->softDeletes();           // دعم الحذف الناعم كما هو مطلوب 
            $table->timestamps();            // لتسجيل وقت الإضافة والتحديث
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('plans');
    }
};
