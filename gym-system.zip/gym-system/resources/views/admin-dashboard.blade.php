<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('messages.dashboard') }}
        </h2>
    </x-slot>

    <div class="py-12" dir="{{ app()->getLocale() == 'ar' ? 'rtl' : 'ltr' }}">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6 border-l-4 border-blue-500">
                    <div class="text-sm font-medium text-gray-500">{{ __('messages.plans') }}</div>
                    <div class="mt-1 text-3xl font-semibold">{{ $stats['total_plans'] }}</div>
                </div>
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6 border-l-4 border-green-500">
                    <div class="text-sm font-medium text-gray-500">{{ __('messages.trainers') }}</div>
                    <div class="mt-1 text-3xl font-semibold">{{ $stats['total_trainers'] }}</div>
                </div>
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6 border-l-4 border-yellow-500">
                    <div class="text-sm font-medium text-gray-500">{{ __('messages.revenue') }}</div>
                    <div class="mt-1 text-3xl font-semibold">${{ number_format($stats['total_revenue'], 2) }}</div>
                </div>
            </div>

            <div class="mb-6 flex justify-end">
    <a href="{{ route('plans.create') }}" class="inline-flex items-center px-6 py-3 bg-indigo-600 border border-transparent rounded-lg font-bold text-sm text-white uppercase tracking-widest hover:bg-indigo-700 active:bg-indigo-900 focus:outline-none focus:border-indigo-900 focus:ring ring-indigo-300 disabled:opacity-25 transition ease-in-out duration-150 shadow-md">
        <svg class="w-5 h-5 {{ app()->getLocale() == 'ar' ? 'ml-2' : 'mr-2' }}" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
        </svg>
        {{ app()->getLocale() == 'ar' ? 'إضافة خطة جديدة' : 'Add New Plan' }}
    </a>
</div>

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-{{ app()->getLocale() == 'ar' ? 'right' : 'left' }} text-xs font-medium text-gray-500 uppercase tracking-wider">
                                {{ __('messages.name') }}
                            </th>
                            <th class="px-6 py-3 text-{{ app()->getLocale() == 'ar' ? 'right' : 'left' }} text-xs font-medium text-gray-500 uppercase tracking-wider">
                                {{ __('messages.price') }}
                            </th>
                            <th class="px-6 py-3 text-{{ app()->getLocale() == 'ar' ? 'right' : 'left' }} text-xs font-medium text-gray-500 uppercase tracking-wider">
                                {{ __('messages.duration') }}
                            </th>
                            <th class="px-6 py-3 text-{{ app()->getLocale() == 'ar' ? 'right' : 'left' }} text-xs font-medium text-gray-500 uppercase tracking-wider">
                                {{ __('messages.actions') }}
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        @foreach($plans as $plan)
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-{{ app()->getLocale() == 'ar' ? 'right' : 'left' }}">
                                {{ $plan->name }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-green-600 font-bold text-{{ app()->getLocale() == 'ar' ? 'right' : 'left' }}">
                                ${{ $plan->price }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-{{ app()->getLocale() == 'ar' ? 'right' : 'left' }}">
                                {{ $plan->duration_days }} {{ app()->getLocale() == 'ar' ? 'يوم' : 'Days' }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-{{ app()->getLocale() == 'ar' ? 'right' : 'left' }}">
                                
                                @if($plan->trashed())
                                    <form action="{{ route('plans.restore', $plan->id) }}" method="POST">
                                        @csrf
                                        <button type="submit" class="text-green-600 hover:text-green-900 font-bold underline">
                                            {{ app()->getLocale() == 'ar' ? 'استرجاع' : 'Restore' }}
                                        </button>
                                    </form>
                                @else
                                    <div class="flex items-center gap-4">
                                        <a href="{{ route('plans.edit', $plan->id) }}" class="text-indigo-600 hover:text-indigo-900 font-bold">
                                            {{ app()->getLocale() == 'ar' ? 'تعديل' : 'Edit' }}
                                        </a>

                                        @php $confirmMsg = app()->getLocale() == 'ar' ? 'هل أنت متأكد؟' : 'Are you sure?'; @endphp
                                        <form action="{{ route('plans.destroy', $plan->id) }}" method="POST" onsubmit="return confirm('{{ $confirmMsg }}')" class="inline">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="text-red-600 hover:text-red-900 font-bold">
                                                {{ app()->getLocale() == 'ar' ? 'حذف' : 'Delete' }}
                                            </button>
                                        </form>
                                    </div>
                                @endif

                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</x-app-layout>