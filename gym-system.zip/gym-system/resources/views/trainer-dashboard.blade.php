<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('messages.dashboard') }} - {{ app()->getLocale() == 'ar' ? 'لوحة المدرب' : 'Trainer View' }}
        </h2>
    </x-slot>

    <div class="py-12" dir="{{ app()->getLocale() == 'ar' ? 'rtl' : 'ltr' }}">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6 border-t-4 border-green-500">
                
                <h3 class="text-lg font-bold mb-6 text-gray-700 text-{{ app()->getLocale() == 'ar' ? 'right' : 'left' }}">
                    {{ __('messages.workout_sessions') }}
                </h3>

                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead>
                            <tr>
                                <th class="px-6 py-3 bg-gray-50 text-{{ app()->getLocale() == 'ar' ? 'right' : 'left' }} text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    {{ __('messages.plan_name') }}
                                </th>
                                <th class="px-6 py-3 bg-gray-50 text-{{ app()->getLocale() == 'ar' ? 'right' : 'left' }} text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    {{ __('messages.start_time') }}
                                </th>
                                <th class="px-6 py-3 bg-gray-50 text-{{ app()->getLocale() == 'ar' ? 'right' : 'left' }} text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    {{ __('messages.status') }}
                                </th>
                                <th class="px-6 py-3 bg-gray-50 text-{{ app()->getLocale() == 'ar' ? 'right' : 'left' }} text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    {{ __('messages.actions') }}
                                </th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            @foreach($sessions as $session)
                            <tr class="hover:bg-gray-50 transition">
                                <td class="px-6 py-4 whitespace-nowrap text-{{ app()->getLocale() == 'ar' ? 'right' : 'left' }} font-medium text-gray-900">
                                    {{ $session->title }}
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-{{ app()->getLocale() == 'ar' ? 'right' : 'left' }} text-sm text-gray-600">
                                    {{ $session->start_time }}
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-{{ app()->getLocale() == 'ar' ? 'right' : 'left' }}">
                                    @if($session->capacity <= 15)
                                        <span class="px-3 py-1 inline-flex text-xs leading-5 font-bold rounded-full bg-green-100 text-green-800">
                                            {{ __('messages.available') }} ({{ $session->capacity }})
                                        </span>
                                    @elseif($session->capacity <= 25)
                                        <span class="px-3 py-1 inline-flex text-xs leading-5 font-bold rounded-full bg-yellow-100 text-yellow-800">
                                            {{ __('messages.almost_full') }} ({{ $session->capacity }})
                                        </span>
                                    @else
                                        <span class="px-3 py-1 inline-flex text-xs leading-5 font-bold rounded-full bg-red-100 text-red-800">
                                            {{ __('messages.full') }} ({{ $session->capacity }})
                                        </span>
                                    @endif
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-{{ app()->getLocale() == 'ar' ? 'right' : 'left' }} text-sm font-medium">
                                    <div class="flex items-center gap-3">
                                        <form action="{{ route('trainer.updateStatus', $session->id) }}" method="POST" class="inline">
                                            @csrf
                                            @method('PATCH')
                                            <button type="submit" class="text-indigo-600 hover:text-indigo-900 font-bold bg-indigo-50 px-3 py-1 rounded shadow-sm transition">
                                                {{ $session->capacity >= 26 ? (app()->getLocale() == 'ar' ? 'فتح التسجيل' : 'Make Available') : (app()->getLocale() == 'ar' ? 'إغلاق (ممتلئ)' : 'Mark as Full') }}
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>

                @if($sessions->isEmpty())
                    <div class="text-center py-8 text-gray-500 italic">
                        {{ __('messages.no_data') }}
                    </div>
                @endif
            </div>
        </div>
    </div>
</x-app-layout>