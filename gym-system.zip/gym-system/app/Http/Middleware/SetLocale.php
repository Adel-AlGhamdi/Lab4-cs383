<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class SetLocale
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle($request, Closure $next)
{
    // فحص إذا كان هناك لغة مخزنة في الـ Session، وإلا استخدم اللغة الافتراضية
    $locale = session('locale', config('app.locale'));
    app()->setLocale($locale);

    return $next($request);
}
}
