<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Plan;
use Illuminate\Support\Facades\Http; // تأكد من إضافة هذا السطر في أعلى الملف مع الـ use

class PlanController extends Controller
{
    // دالة لحذف الخطة (Soft Delete)
    public function destroy($id)
    {
        $plan = Plan::findOrFail($id);
        $plan->delete();
        return redirect()->back()->with('success', 'Plan moved to trash!');
    }

    // دالة لاسترجاع الخطة المحذوفة
    public function restore($id)
    {
        Plan::withTrashed()->findOrFail($id)->restore();
        return redirect()->back()->with('success', 'Plan restored!');
    }

    // لعرض صفحة الفورم
public function create()
{
    return view('plans.create');
}

// لحفظ البيانات المكتوبة في الفورم
public function store(Request $request)
{
    // 1. التحقق من البيانات (الموجود أصلاً)
    $request->validate([
        'name' => 'required',
        'price' => 'required|numeric',
        'duration_days' => 'required|integer',
    ]);

    // 2. حفظ الخطة في قاعدة البيانات (الموجود أصلاً)
    // لاحظ أننا وضعنا النتيجة في متغير اسمه $plan لنستخدمه في الإرسال
    $plan = \App\Models\Plan::create($request->all());

    // 3. إضافة كود الإرسال إلى n8n (هذا هو الإضافة الجديدة)
    try {
        Http::post('https://adel-23.app.n8n.cloud/webhook/new-plan', [
            'event' => 'New Plan Created',
            'plan_name' => $plan->name,
            'price' => $plan->price . ' SAR',
            'duration' => $plan->duration_days . ' Days',
            'admin' => auth()->user()->name,
            'timestamp' => now()->toDateTimeString(),
        ]);
    } catch (\Exception $e) {
        // في حال فشل n8n لا نريد أن يظهر خطأ للمستخدم
    }

    // 4. إعادة التوجيه (الموجود أصلاً)
    return redirect()->route('admin.dashboard')->with('success', 'Plan created and automation triggered!');
}

// 1. عرض صفحة التعديل مع بيانات الخطة القديمة
public function edit($id)
{
    $plan = Plan::findOrFail($id);
    return view('plans.edit', compact('plan'));
}

// 2. استقبال البيانات الجديدة وحفظها
public function update(Request $request, $id)
{
    $request->validate([
        'name' => 'required',
        'price' => 'required|numeric',
        'duration_days' => 'required|integer',
    ]);

    $plan = Plan::findOrFail($id);
    $plan->update($request->all());

    return redirect()->route('admin.dashboard')->with('success', 'Plan updated successfully!');
}
}



