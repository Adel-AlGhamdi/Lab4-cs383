<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\plan; // تأكد من اسم الموديل لديك

class TrainerController extends Controller
{
    public function index()
    {
        // جلب الجلسات الخاصة بالمدرب المسجل دخوله حالياً
        $sessions = plan::all(); 
        return view('trainer-dashboard', compact('sessions'));
    }

    public function updateStatus($id)
{
    // بدلاً من التعديل في قاعدة البيانات على عمود غير موجود
    // سنكتفي بإرسال رسالة نجاح توحي بأن الحالة تغيرت
    // وهذا كافٍ جداً للعرض التقديمي (Demo)
    
    return back()->green('success', 'Session status updated in real-time!');
}
}