<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class GymSession extends Model
{
    use SoftDeletes;

    // السماح بتعبئة بيانات الحصص الرياضية
    protected $fillable = ['title', 'description', 'start_time', 'capacity']; 
}