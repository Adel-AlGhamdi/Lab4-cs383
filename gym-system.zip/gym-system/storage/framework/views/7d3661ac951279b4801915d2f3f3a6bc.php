<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('messages.dashboard')); ?> - <?php echo e(app()->getLocale() == 'ar' ? 'لوحة المدرب' : 'Trainer View'); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12" dir="<?php echo e(app()->getLocale() == 'ar' ? 'rtl' : 'ltr'); ?>">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6 border-t-4 border-green-500">
                
                <h3 class="text-lg font-bold mb-6 text-gray-700 text-<?php echo e(app()->getLocale() == 'ar' ? 'right' : 'left'); ?>">
                    <?php echo e(__('messages.workout_sessions')); ?>

                </h3>

                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead>
                            <tr>
                                <th class="px-6 py-3 bg-gray-50 text-<?php echo e(app()->getLocale() == 'ar' ? 'right' : 'left'); ?> text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    <?php echo e(__('messages.plan_name')); ?>

                                </th>
                                <th class="px-6 py-3 bg-gray-50 text-<?php echo e(app()->getLocale() == 'ar' ? 'right' : 'left'); ?> text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    <?php echo e(__('messages.start_time')); ?>

                                </th>
                                <th class="px-6 py-3 bg-gray-50 text-<?php echo e(app()->getLocale() == 'ar' ? 'right' : 'left'); ?> text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    <?php echo e(__('messages.status')); ?>

                                </th>
                                <th class="px-6 py-3 bg-gray-50 text-<?php echo e(app()->getLocale() == 'ar' ? 'right' : 'left'); ?> text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    <?php echo e(__('messages.actions')); ?>

                                </th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-50 transition">
                                <td class="px-6 py-4 whitespace-nowrap text-<?php echo e(app()->getLocale() == 'ar' ? 'right' : 'left'); ?> font-medium text-gray-900">
                                    <?php echo e($session->title); ?>

                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-<?php echo e(app()->getLocale() == 'ar' ? 'right' : 'left'); ?> text-sm text-gray-600">
                                    <?php echo e($session->start_time); ?>

                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-<?php echo e(app()->getLocale() == 'ar' ? 'right' : 'left'); ?>">
                                    <?php if($session->capacity <= 15): ?>
                                        <span class="px-3 py-1 inline-flex text-xs leading-5 font-bold rounded-full bg-green-100 text-green-800">
                                            <?php echo e(__('messages.available')); ?> (<?php echo e($session->capacity); ?>)
                                        </span>
                                    <?php elseif($session->capacity <= 25): ?>
                                        <span class="px-3 py-1 inline-flex text-xs leading-5 font-bold rounded-full bg-yellow-100 text-yellow-800">
                                            <?php echo e(__('messages.almost_full')); ?> (<?php echo e($session->capacity); ?>)
                                        </span>
                                    <?php else: ?>
                                        <span class="px-3 py-1 inline-flex text-xs leading-5 font-bold rounded-full bg-red-100 text-red-800">
                                            <?php echo e(__('messages.full')); ?> (<?php echo e($session->capacity); ?>)
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-<?php echo e(app()->getLocale() == 'ar' ? 'right' : 'left'); ?> text-sm font-medium">
                                    <div class="flex items-center gap-3">
                                        <form action="<?php echo e(route('trainer.updateStatus', $session->id)); ?>" method="POST" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <button type="submit" class="text-indigo-600 hover:text-indigo-900 font-bold bg-indigo-50 px-3 py-1 rounded shadow-sm transition">
                                                <?php echo e($session->capacity >= 26 ? (app()->getLocale() == 'ar' ? 'فتح التسجيل' : 'Make Available') : (app()->getLocale() == 'ar' ? 'إغلاق (ممتلئ)' : 'Mark as Full')); ?>

                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <?php if($sessions->isEmpty()): ?>
                    <div class="text-center py-8 text-gray-500 italic">
                        <?php echo e(__('messages.no_data')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\gym-system\resources\views/trainer-dashboard.blade.php ENDPATH**/ ?>