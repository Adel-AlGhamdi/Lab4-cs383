<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('messages.dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12" dir="<?php echo e(app()->getLocale() == 'ar' ? 'rtl' : 'ltr'); ?>">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6 border-l-4 border-blue-500">
                    <div class="text-sm font-medium text-gray-500"><?php echo e(__('messages.plans')); ?></div>
                    <div class="mt-1 text-3xl font-semibold"><?php echo e($stats['total_plans']); ?></div>
                </div>
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6 border-l-4 border-green-500">
                    <div class="text-sm font-medium text-gray-500"><?php echo e(__('messages.trainers')); ?></div>
                    <div class="mt-1 text-3xl font-semibold"><?php echo e($stats['total_trainers']); ?></div>
                </div>
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6 border-l-4 border-yellow-500">
                    <div class="text-sm font-medium text-gray-500"><?php echo e(__('messages.revenue')); ?></div>
                    <div class="mt-1 text-3xl font-semibold">$<?php echo e(number_format($stats['total_revenue'], 2)); ?></div>
                </div>
            </div>

            <div class="mb-6 flex justify-end">
    <a href="<?php echo e(route('plans.create')); ?>" class="inline-flex items-center px-6 py-3 bg-indigo-600 border border-transparent rounded-lg font-bold text-sm text-white uppercase tracking-widest hover:bg-indigo-700 active:bg-indigo-900 focus:outline-none focus:border-indigo-900 focus:ring ring-indigo-300 disabled:opacity-25 transition ease-in-out duration-150 shadow-md">
        <svg class="w-5 h-5 <?php echo e(app()->getLocale() == 'ar' ? 'ml-2' : 'mr-2'); ?>" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
        </svg>
        <?php echo e(app()->getLocale() == 'ar' ? 'إضافة خطة جديدة' : 'Add New Plan'); ?>

    </a>
</div>

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-<?php echo e(app()->getLocale() == 'ar' ? 'right' : 'left'); ?> text-xs font-medium text-gray-500 uppercase tracking-wider">
                                <?php echo e(__('messages.name')); ?>

                            </th>
                            <th class="px-6 py-3 text-<?php echo e(app()->getLocale() == 'ar' ? 'right' : 'left'); ?> text-xs font-medium text-gray-500 uppercase tracking-wider">
                                <?php echo e(__('messages.price')); ?>

                            </th>
                            <th class="px-6 py-3 text-<?php echo e(app()->getLocale() == 'ar' ? 'right' : 'left'); ?> text-xs font-medium text-gray-500 uppercase tracking-wider">
                                <?php echo e(__('messages.duration')); ?>

                            </th>
                            <th class="px-6 py-3 text-<?php echo e(app()->getLocale() == 'ar' ? 'right' : 'left'); ?> text-xs font-medium text-gray-500 uppercase tracking-wider">
                                <?php echo e(__('messages.actions')); ?>

                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-<?php echo e(app()->getLocale() == 'ar' ? 'right' : 'left'); ?>">
                                <?php echo e($plan->name); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-green-600 font-bold text-<?php echo e(app()->getLocale() == 'ar' ? 'right' : 'left'); ?>">
                                $<?php echo e($plan->price); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-<?php echo e(app()->getLocale() == 'ar' ? 'right' : 'left'); ?>">
                                <?php echo e($plan->duration_days); ?> <?php echo e(app()->getLocale() == 'ar' ? 'يوم' : 'Days'); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-<?php echo e(app()->getLocale() == 'ar' ? 'right' : 'left'); ?>">
                                
                                <?php if($plan->trashed()): ?>
                                    <form action="<?php echo e(route('plans.restore', $plan->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="text-green-600 hover:text-green-900 font-bold underline">
                                            <?php echo e(app()->getLocale() == 'ar' ? 'استرجاع' : 'Restore'); ?>

                                        </button>
                                    </form>
                                <?php else: ?>
                                    <div class="flex items-center gap-4">
                                        <a href="<?php echo e(route('plans.edit', $plan->id)); ?>" class="text-indigo-600 hover:text-indigo-900 font-bold">
                                            <?php echo e(app()->getLocale() == 'ar' ? 'تعديل' : 'Edit'); ?>

                                        </a>

                                        <?php $confirmMsg = app()->getLocale() == 'ar' ? 'هل أنت متأكد؟' : 'Are you sure?'; ?>
                                        <form action="<?php echo e(route('plans.destroy', $plan->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e($confirmMsg); ?>')" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="text-red-600 hover:text-red-900 font-bold">
                                                <?php echo e(app()->getLocale() == 'ar' ? 'حذف' : 'Delete'); ?>

                                            </button>
                                        </form>
                                    </div>
                                <?php endif; ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\gym-system\resources\views/admin-dashboard.blade.php ENDPATH**/ ?>